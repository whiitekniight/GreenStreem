# GreenStreem Recorder — Windows preview

Run the recorder on the customer's Windows PC. The phone, tablet and TV app send
schedules to this PC; they are not the recorder and can be off after confirmation.
No customer recordings are stored on GreenStreem's servers or the developer's NAS.

## Setup

1. Open `GreenStreem Recorder.exe` and choose an **existing** recording folder.
   This can be a local disk, USB disk, or NAS share accessible in File Explorer.
   For a NAS, sign in to the share in Windows first. The recorder uses the same
   Windows account. A UNC path such as `\\nas\video\IPTV Downloads` is preferable
   to a mapped drive that might not be available after sign-in.
2. If Windows asks, allow the recorder on your **private home network**. Do not
   forward ports on your router. It uses TCP 8791 and UDP 8792 for discovery.
3. Click **Connect a device**. In GreenStreem Android preview 1.9.71+, open
   **Recordings → Set up PC recorder → Find my PC recorder**. Select the PC and
   enter its one-use, five-minute code. If discovery is blocked, enter the address
   shown on the PC instead.
4. Hold a guide program, choose **Schedule recording**, then confirm **Record on PC**.
   Wait for **PC confirmed the schedule** before turning off the tablet or TV.
5. Open **Recordings → PC recorder** to see schedules, stop jobs, replay, or delete.

## What stays on?

Keep the PC on, Windows signed in, GreenStreem Recorder running, and the chosen
drive/NAS connected. The recorder prevents automatic sleep while it runs. It
cannot record while the PC is shut down, signed out, manually put to sleep, or
offline. Closing its window offers to minimize and keep recording. Optional
**Start recorder when I sign in to Windows** restarts it at user sign-in, not
before login. Existing schedules persist across recorder restarts; an in-progress
recording resumes when possible, with any outage remaining a gap in the recording.

## First release boundaries

- One recording at a time, MPEG-TS live channels, up to 24 hours per job.
- Schedule from EPG, or use the 30-second test in the app. Provider connection
  limits still apply, including viewing while recording.
- Reconnects to the original provider URL on source interruption, without
  replacing/truncating an existing output file. It cannot reconstruct missed video.
- Replay and seek via authenticated HTTP byte ranges on the home network.
- Every paired device can manage this household recorder's schedules and files.
  Use **Disconnect devices** on the PC to revoke access. This is not a public,
  multi-customer hosted service and must not be exposed to the internet.
- Home-network HTTP is used; traffic is not end-to-end encrypted. Provider URLs
  stored in the PC database are encrypted with Windows DPAPI for its signed-in
  account. Device tokens are hashed on the PC and encrypted with Android Keystore
  on Android. Tokens/provider URLs are not placed in replay URLs or server logs.
- Server folder selection is separate from Android's existing local/USB/NAS
  selection. Switching the app destination does not migrate or cancel existing jobs.
- No automatic deletion, NAS subfolder creation, file migration, router changes,
  startup changes, or public publishing occurs during setup.

## Development

Python 3.12+ on Windows; no runtime pip packages required:

```
python app.py
python -m unittest discover -s tests -v
python -m PyInstaller --noconfirm --clean --windowed --onedir --name "GreenStreem Recorder" app.py
```

Copy the entire generated `dist/GreenStreem Recorder` folder to a stable location
before enabling Windows startup. Source and runnable distribution belong in this
project folder. App data is `%LOCALAPPDATA%\GreenStreem Recorder`; do not delete
that folder to update the application.
