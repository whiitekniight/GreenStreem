# GreenStreem Recorder — Windows / Linux preview 0.2.0

Run the recorder on the customer's Windows PC. The phone, tablet and TV app send
schedules to this PC; they are not the recorder and can be off after confirmation.
No customer recordings are stored on GreenStreem's servers or the developer's NAS.

## Setup

1. Open `GreenStreem Recorder.exe` and choose an **existing** recording folder.
   This can be a local disk, USB disk, or NAS share accessible in File Explorer.
   For a NAS, sign in to the share in Windows first. The recorder uses the same
   Windows account. A UNC path such as `\\nas\video\IPTV Downloads` is preferable
   to a mapped drive that might not be available after sign-in.
2. If Windows asks, allow the recorder on your **private home network**. Do not
   forward ports on your router. It uses TCP 8791 and UDP 8792 for discovery.
3. Click **Connect a device**. In GreenStreem Android preview 1.9.71+, open
   **Recordings → Set up PC recorder → Find my PC recorder**. Select the PC and
   enter its one-use, five-minute code. If discovery is blocked, enter the address
   shown on the PC instead.
4. Hold a guide program, choose **Schedule recording**, then confirm **Record on PC**.
   Wait for **PC confirmed the schedule** before turning off the tablet or TV.
5. Open **Recordings → PC recorder** to see schedules, stop jobs, replay, or delete.

## What stays on?

Keep the PC on, Windows signed in, GreenStreem Recorder running, and the chosen
drive/NAS connected. The recorder prevents automatic sleep while it runs. It
cannot record while the PC is shut down, signed out, manually put to sleep, or
offline. Closing its window offers to minimize and keep recording. Optional
**Start recorder when I sign in to Windows** restarts it at user sign-in, not
before login. Existing schedules persist across recorder restarts; an in-progress
recording resumes when possible, with any outage remaining a gap in the recording.

## First release boundaries

- One recording at a time, MPEG-TS live channels, up to 24 hours per job.
- Schedule from EPG, or use the 30-second test in the app. Provider connection
  limits still apply, including viewing while recording.
- Temporary source interruptions, truncated HTTP responses and expired-link error pages retry until the scheduled end; they do not end the program after a fixed retry count. Select a recording on the PC to see reconnection or storage details.
- Reconnects to the original provider URL on source interruption, without
  replacing/truncating an existing output file. It cannot reconstruct missed video.
- Replay and seek via authenticated HTTP byte ranges on the home network.
- Every paired device can manage this household recorder's schedules and files.
  Use **Disconnect devices** on the PC to revoke access. This is not a public,
  multi-customer hosted service and must not be exposed to the internet.
- Home-network HTTP is used; traffic is not end-to-end encrypted. Provider URLs
  stored in the PC database are encrypted with Windows DPAPI for its signed-in
  account. Device tokens are hashed on the PC and encrypted with Android Keystore
  on Android. Tokens/provider URLs are not placed in replay URLs or server logs.
- Server folder selection is separate from Android's existing local/USB/NAS
  selection. Switching the app destination does not migrate or cancel existing jobs.
- No automatic deletion, NAS subfolder creation, file migration, router changes,
  startup changes, or public publishing occurs during setup.

## Development

Python 3.12+ on Windows; no runtime pip packages required:

```
python app.py
python -m unittest discover -s tests -v
./build.ps1
```

Copy the entire generated `dist/GreenStreem Recorder` folder to a stable location
before enabling Windows startup. Source and runnable distribution belong in this
project folder. App data is `%LOCALAPPDATA%\GreenStreem Recorder`; do not delete
that folder to update the application.


## 0.2.0 preview: recording controls and weekly schedules

The Android app can record now, stop/cancel from a guide program, and schedule
weekly at the same local time. Choose extra minutes before and after a program
(default three each). A weekly rule records that channel/time slot even when the
guide title changes. Cancelling any occurrence stops future repeats and keeps
saved video. Cancel repeats before deleting a recurring recording. One recording
at a time is supported; overlapping requests are rejected. Weekly time follows
the device time zone captured when scheduled, including daylight-saving changes.

Computer recordings now appear beside device recordings in Android Recordings;
no separate SMB share is needed. Both devices must be on the same home network
for scheduling, management or replay. The recorder computer must remain on and
its drive accessible to record; the Android device may be off after confirmation.

## Linux desktop and headless preview

Requires Python 3.10+, python3-venv and python3-tk (desktop). On Debian/Ubuntu,
install those packages, extract this folder, and run `sh start-recorder.sh`.
It creates a private Python environment, installs the listed dependencies, and
opens the same branded folder chooser and Connect a device screen as Windows.
Choose an existing local/USB folder or a NAS share already mounted in the Linux
file manager. Keep Linux awake; the desktop checkbox can start the recorder at
sign-in. It does not disable system sleep on Linux.

For a headless machine use `.venv/bin/python linux_recorder.py --folder
"/your/existing/folder" --pair`. The code printed in the terminal lasts five
minutes. Discover/connect from Android's recorder setup. Data and encryption key
live under `~/.local/share/greenstreem-recorder`; protect this directory and keep
its key with its database. Credentials are encrypted with Fernet on Linux and
Windows account protection on Windows. These databases cannot be moved between
operating systems. Only allow ports 8791/TCP and 8792/UDP on the private LAN;
do not forward them on your router. NAS firmware without Python/Tk or a mounted
writable share is not a supported desktop host.

Windows builders: `python -m pip install -r requirements-build.txt`, then run
`build.ps1`. Time-zone data is bundled for weekly schedules.
