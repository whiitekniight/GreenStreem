"""Headless Linux recorder; use the same Android discovery and pairing screen."""
import argparse
import fcntl
import os
from pathlib import Path
import signal
from recorder import Recorder


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=Path.home()/'.local/share/greenstreem-recorder')
    parser.add_argument('--folder', type=Path, help='Existing local, USB or mounted NAS folder')
    parser.add_argument('--pair', action='store_true', help='Show a single-use five-minute connection code')
    args = parser.parse_args()
    os.umask(0o077)
    args.data.mkdir(parents=True, exist_ok=True)
    with (args.data/'instance.lock').open('a+b') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            parser.error('A recorder is already running with this data folder')
        recorder = Recorder(args.data)
        if args.folder:
            recorder.configure_folder(args.folder)
        if not recorder.setting('folder'):
            parser.error('Choose an existing folder with --folder first')
        if args.pair:
            print('Connection code (five minutes):', recorder.pairing_code(), flush=True)
        print('GreenStreem Recorder - port 8791 - saving to', recorder.setting('folder'), flush=True)
        recorder.start()
        signal.signal(signal.SIGTERM, lambda *_: recorder.stop_event.set())
        signal.signal(signal.SIGINT, lambda *_: recorder.stop_event.set())
        try:
            recorder.stop_event.wait()
        finally:
            recorder.close()


if __name__ == '__main__':
    main()
