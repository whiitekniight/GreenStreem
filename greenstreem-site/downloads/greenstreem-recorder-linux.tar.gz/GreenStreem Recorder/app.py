"""Windows desktop control panel; recording continues while this window is minimized."""
import ctypes
import os
from pathlib import Path
import socket
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
if os.name == "nt":
    import winreg

from recorder import Recorder


def main():
    if os.name == 'nt':
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('GreenStreem.Recorder')
    data = Path(os.environ['LOCALAPPDATA']) / 'GreenStreem Recorder' if os.name == 'nt' else Path.home()/'.local/share/greenstreem-recorder'
    data.mkdir(parents=True, exist_ok=True)
    # OS releases this lock after a crash; a second worker must never run the same jobs.
    if os.name == "nt":
        import msvcrt
    else:
        import fcntl
    lock = (data / 'instance.lock').open('a+b')
    try:
        lock.seek(0)
        if lock.read(1) == b'':
            lock.write(b'1'); lock.flush()
        lock.seek(0)
        if os.name == "nt":
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        notice = tk.Tk()
        notice.withdraw()
        if os.name == 'nt':
            notice.iconbitmap(default=str(Path(__file__).resolve().parent / 'assets' / 'greenstreem.ico'))
        messagebox.showinfo('GreenStreem Recorder', 'GreenStreem Recorder is already running. Open it from the taskbar.',parent=notice)
        notice.destroy()
        return
    root = tk.Tk()
    root.title('GreenStreem Recorder')
    assets = Path(__file__).resolve().parent / 'assets'
    if os.name == 'nt':
        root.iconbitmap(default=str(assets / 'greenstreem.ico'))
    root.geometry('960x820')
    root.minsize(900, 760)
    root.configure(bg='#101820')
    style = ttk.Style(root)
    style.theme_use('clam')
    style.configure('TFrame', background='#101820')
    style.configure('TLabel', background='#101820', foreground='#edf5f7', font=('Segoe UI',11))
    style.configure('TButton', background='#152b38', foreground='#81dfb2', padding=(15,10), font=('Segoe UI',10,'bold'))
    style.map('TButton', background=[('active','#235044')])
    style.configure('Treeview', background='#17232e', fieldbackground='#17232e', foreground='white', rowheight=32)
    style.configure('Treeview.Heading', background='#203746', foreground='white')
    frame = ttk.Frame(root, padding=22)
    frame.pack(fill='both',expand=True)
    heading = ttk.Frame(frame)
    heading.pack(fill='x')
    logo = tk.PhotoImage(file=str(assets / 'greenstreem-64.png'))
    root.iconphoto(True,logo)
    ttk.Label(heading,image=logo).pack(side='left',padx=(0,14))
    ttk.Label(heading,text='GreenStreem Recorder',font=('Segoe UI',24,'bold')).pack(side='left')
    ttk.Label(frame,text='Schedule in the app. Your PC records while your phone, tablet or TV is off.',wraplength=820).pack(anchor='w',pady=(6,16))
    recorder = Recorder(data)
    try:
        recorder.start()
    except OSError:
        messagebox.showerror('Could not start recorder','The recording server port is already in use. Close the other recorder and try again.')
        root.destroy();return
    try:
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
            route.connect(('8.8.8.8',80))  # Routing lookup only; no packets are sent.
            addresses=[route.getsockname()[0]]
    except OSError:
        addresses = sorted({entry[4][0] for entry in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET) if not entry[4][0].startswith(('127.','169.254.'))})
    ttk.Label(frame,text='Connect on your home network: '+', '.join(f'{ip}:{recorder.port}' for ip in addresses),wraplength=820).pack(anchor='w')
    folder_text=tk.StringVar()
    ttk.Label(frame,textvariable=folder_text,wraplength=820).pack(anchor='w',pady=(10,10))
    ttk.Label(frame,text='1  Choose a folder the PC can write to. For NAS storage, open the share in File Explorer and sign in first.',wraplength=850,foreground='#a8bac5',font=('Segoe UI',10)).pack(anchor='w')
    controls=ttk.Frame(frame);controls.pack(fill='x',pady=8)
    def folder():
        chosen=filedialog.askdirectory(title='Choose an existing local, USB or NAS recording folder',mustexist=True)
        if chosen:
            try: recorder.configure_folder(chosen)
            except OSError: messagebox.showerror('Folder unavailable','Could not write to that folder. Open or mount the NAS share in your file manager and sign in first.')
            except ValueError as exc: messagebox.showerror('Folder unavailable',str(exc))
    ttk.Button(controls,text='Choose recording folder',command=folder).pack(side='left',padx=(0,12))
    code_text=tk.StringVar(value='2  Click Connect a device, then enter its code in the app.')
    def code():
        code_text.set('Connection code: '+recorder.pairing_code()+'   •   One use, valid for 5 minutes')
    ttk.Button(controls,text='Connect a device',command=code).pack(side='left',padx=(0,12))
    def forget():
        if messagebox.askyesno('Disconnect devices?','All devices will need a new connection code. Scheduled recordings will stay on this PC.'):
            with recorder.db() as db: db.execute('DELETE FROM devices')
    ttk.Button(controls,text='Disconnect devices',command=forget).pack(side='left')
    ttk.Label(frame,textvariable=code_text,foreground='#80dfad',font=('Segoe UI',14,'bold')).pack(anchor='w',pady=10)
    columns=('title','channel','state','size')
    ttk.Label(frame,text='3  Schedule in the app and wait for PC confirmation. Replay directly under Recordings in the app.',wraplength=850,foreground='#a8bac5',font=('Segoe UI',10)).pack(anchor='w',pady=(0,4))
    tree=ttk.Treeview(frame,columns=columns,show='headings',selectmode='browse',height=5)
    for name,width in zip(columns,(290,210,130,90)):
        tree.heading(name,text=name.title());tree.column(name,width=width)
    tree.pack(fill='both',expand=True,pady=(8,12))
    detail_text=tk.StringVar(value='Select a recording to see its status or any connection/storage problem.')
    ttk.Label(frame,textvariable=detail_text,wraplength=850,foreground='#a8bac5',font=('Segoe UI',10)).pack(anchor='w',pady=(0,8))
    def detail(_=None):
        if tree.selection():
            row=recorder.job(tree.selection()[0])
            detail_text.set(row['state']+': '+(row['detail'] or 'No recording errors reported.'))
    tree.bind('<<TreeviewSelect>>',detail)
    actions=ttk.Frame(frame);actions.pack(fill='x')
    def stop_job():
        if tree.selection(): recorder.cancel(tree.selection()[0])
    def delete():
        if tree.selection() and messagebox.askyesno('Delete recording?','Permanently delete the selected recording file and schedule?'):
            try: recorder.delete(tree.selection()[0])
            except (ValueError,OSError) as exc: messagebox.showerror('Could not delete',str(exc))
    ttk.Button(actions,text='Stop selected recording',command=stop_job).pack(side='left',padx=(0,12))
    ttk.Button(actions,text='Delete selected',command=delete).pack(side='left')
    autostart=Path.home()/'.config/autostart/greenstreem-recorder.desktop'
    def desktop_entry():
        import shlex
        command=' '.join('"'+part.replace('\\','\\\\').replace('"','\\"').replace('`','\\`').replace('$','\\$')+'"' for part in [sys.executable,str(Path(__file__).resolve())])
        return '[Desktop Entry]\nType=Application\nName=GreenStreem Recorder\nExec='+command+'\nIcon='+str(Path(__file__).resolve().parent/'assets/greenstreem-64.png')+'\nTerminal=false\n'
    def startup_command():
        import subprocess
        return subprocess.list2cmdline([sys.executable] if getattr(sys,'frozen',False) else [sys.executable,str(Path(__file__).resolve())])
    def startup_enabled():
        if os.name != 'nt':
            return autostart.exists() and autostart.read_text()==desktop_entry()
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,r'Software\Microsoft\Windows\CurrentVersion\Run') as key:
                return winreg.QueryValueEx(key,'GreenStreemRecorder')[0]==startup_command()
        except OSError: return False
    startup=tk.BooleanVar(value=startup_enabled())
    def toggle_startup():
        if os.name != 'nt':
            try:
                if startup.get():
                    autostart.parent.mkdir(parents=True,exist_ok=True);autostart.write_text(desktop_entry())
                else:
                    autostart.unlink(missing_ok=True)
            except OSError:
                startup.set(startup_enabled());messagebox.showerror('Startup','Could not save automatic startup.')
            return
        try:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER,r'Software\Microsoft\Windows\CurrentVersion\Run') as key:
                if startup.get(): winreg.SetValueEx(key,'GreenStreemRecorder',0,winreg.REG_SZ,startup_command())
                else:
                    try: winreg.DeleteValue(key,'GreenStreemRecorder')
                    except FileNotFoundError: pass
        except OSError:
            startup.set(startup_enabled());messagebox.showerror('Windows startup','Windows could not save this startup setting.')
    tk.Checkbutton(frame,text='Start recorder when I sign in',variable=startup,command=toggle_startup,bg='#101820',fg='white',selectcolor='#203746',activebackground='#101820',activeforeground='white').pack(anchor='w',pady=(12,5))
    ttk.Label(frame,text='Keep this PC on and signed in, this recorder running, and storage connected. Sleep is prevented on Windows; disable automatic sleep on Linux. Closing the recorder or shutting down the PC stops recording. Home network only; no router port forwarding.',wraplength=820,foreground='#a8bac5',font=('Segoe UI',10)).pack(anchor='w')
    def refresh():
        folder_text.set('Saving to: '+(recorder.setting('folder') or 'Choose a folder before scheduling'))
        if recorder.code and recorder.code_until <= __import__('time').monotonic(): code_text.set('Connection code expired. Click Connect a device for a new code.')
        selected=tree.selection()
        scroll=tree.yview()
        rows=recorder.jobs()
        tree.delete(*tree.get_children())
        for row in rows:
            tree.insert('', 'end', iid=row['id'],values=(row['title'],row['channel'],row['state'],f"{row['bytes']/1048576:.1f} MB"))
        if selected and tree.exists(selected[0]): tree.selection_set(selected);detail()
        if scroll: tree.yview_moveto(scroll[0])
        root.after(2000,refresh)
    def close():
        result=messagebox.askyesnocancel('Keep recording?','Keep GreenStreem Recorder running in the taskbar?\n\nYes: minimize and keep recording.\nNo: stop the recorder and exit.')
        if result is True: root.iconify()
        elif result is False:
            root.withdraw()
            def finish():
                recorder.close();root.after(0,root.destroy)
            threading.Thread(target=finish,daemon=True).start()
    root.protocol('WM_DELETE_WINDOW',close)
    refresh()
    root.mainloop()
    lock.close()


if __name__=='__main__':
    main()
