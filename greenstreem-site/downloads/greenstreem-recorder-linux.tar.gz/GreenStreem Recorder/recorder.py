"""GreenStreem Recorder: persistent, authenticated home-network recording server."""
from __future__ import annotations

import base64
import ctypes
import hashlib
import hmac
import http.client
import http.server
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import sqlite3
import threading
import time
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
import uuid
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from contextlib import contextmanager

PORT = 8791
DISCOVERY_PORT = 8792
ACTIVE = ('Scheduled', 'Recording')


class StreamUnavailable(Exception):
    """An upstream response that may recover; never write its body to disk."""


def protect(value: str, decrypt=False) -> str:
    """Bind provider credentials to the Windows account running the recorder."""
    if os.name != 'nt':
        raise RuntimeError('This release requires Windows')
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_char))]
    raw = base64.b64decode(value) if decrypt else value.encode()
    buffer = ctypes.create_string_buffer(raw)
    source = Blob(len(raw), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_char)))
    result = Blob()
    function = ctypes.windll.crypt32.CryptUnprotectData if decrypt else ctypes.windll.crypt32.CryptProtectData
    if not function(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result)):
        raise ctypes.WinError()
    try:
        raw = ctypes.string_at(result.data, result.size)
        return raw.decode() if decrypt else base64.b64encode(raw).decode()
    finally:
        ctypes.windll.kernel32.LocalFree(ctypes.cast(result.data, ctypes.c_void_p))


def schedules_overlap(start, end, weekly, zone, existing):
    """Compare a rolling year of weekly wall-clock slots without concurrent streams."""
    horizon = max(start, existing['start']) + 370*86400000
    floor = max(start, existing['start']) - 86400000
    def occurrences(a, b, repeat, tz):
        a, b = datetime.fromtimestamp(a/1000, ZoneInfo(tz)), datetime.fromtimestamp(b/1000, ZoneInfo(tz))
        while repeat and b.timestamp()*1000 < floor:
            a += timedelta(days=7); b += timedelta(days=7)
        while a.timestamp()*1000 < horizon:
            yield int(a.timestamp()*1000), int(b.timestamp()*1000)
            if not repeat:
                break
            a += timedelta(days=7); b += timedelta(days=7)
    left = iter(occurrences(start,end,weekly,zone))
    right = iter(occurrences(existing['start'],existing['end'],existing['weekly'],existing['zone']))
    a, b = next(left,None), next(right,None)
    while a and b:
        if a[0] < b[1] and a[1] > b[0]:
            return True
        if a[1] <= b[0]: a = next(left,None)
        else: b = next(right,None)
    return False


class Recorder:
    def __init__(self, data: Path, port=PORT):
        self.data = Path(data)
        self.data.mkdir(parents=True, exist_ok=True)
        self.port = port
        if os.name != 'nt':
            os.chmod(self.data, 0o700)
            from cryptography.fernet import Fernet
            key_path = self.data / 'credentials.key'
            if not key_path.exists():
                with key_path.open('xb') as key_file:
                    os.chmod(key_path, 0o600)
                    key_file.write(Fernet.generate_key())
            os.chmod(key_path, 0o600)
            self.cipher = Fernet(key_path.read_bytes())
        self.stop_event = threading.Event()
        self.active = {}
        self.lock = threading.RLock()
        self.code = ''
        self.code_until = 0
        self.pair_attempts = {}
        self.retry_delays = (1, 2, 4, 8, 15, 30)
        with self.db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS devices (hash TEXT PRIMARY KEY, name TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL, channel TEXT NOT NULL,
                    source TEXT NOT NULL, start INTEGER NOT NULL, end INTEGER NOT NULL,
                    path TEXT NOT NULL, state TEXT NOT NULL, bytes INTEGER NOT NULL DEFAULT 0,
                    detail TEXT NOT NULL DEFAULT '');
            ''')
            columns = {r[1] for r in db.execute('PRAGMA table_info(jobs)')}
            for name, definition in [('weekly', 'INTEGER NOT NULL DEFAULT 0'), ('zone', "TEXT NOT NULL DEFAULT 'UTC'"), ('series', "TEXT NOT NULL DEFAULT ''"), ('advanced', 'INTEGER NOT NULL DEFAULT 0'), ('guide_start', 'INTEGER NOT NULL DEFAULT 0'), ('guide_end', 'INTEGER NOT NULL DEFAULT 0')]:
                if name not in columns:
                    db.execute(f'ALTER TABLE jobs ADD COLUMN {name} {definition}')
            # An interrupted recording resumes from its original URL, appending to its own file.
            db.execute("UPDATE jobs SET state='Scheduled', detail='Resuming after recorder restart' WHERE state='Recording'")
        self.http = None

    def protect(self, value, decrypt=False):
        if os.name == 'nt':
            return protect(value, decrypt)
        return self.cipher.decrypt(value.encode()).decode() if decrypt else self.cipher.encrypt(value.encode()).decode()

    @contextmanager
    def db(self):
        db = sqlite3.connect(self.data / 'recorder.db', timeout=15)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def setting(self, key, default=''):
        with self.db() as db:
            row = db.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
            return row[0] if row else default

    def configure_folder(self, folder):
        folder = Path(folder).resolve(strict=True)
        if not folder.is_dir():
            raise ValueError('Choose an existing recording folder')
        probe = folder / ('.greenstreem-write-test-' + uuid.uuid4().hex)
        try:
            with probe.open('xb') as stream:
                stream.write(b'test')
        finally:
            probe.unlink(missing_ok=True)
        with self.db() as db:
            db.execute('INSERT OR REPLACE INTO settings VALUES (?,?)', ('folder', str(folder)))

    def pairing_code(self):
        with self.lock:
            self.code = f'{secrets.randbelow(1000000):06d}'
            self.code_until = time.monotonic() + 300
            return self.code

    def pair(self, code, name, address):
        with self.lock:
            attempts = [t for t in self.pair_attempts.get(address, []) if t > time.monotonic() - 300]
            if len(attempts) >= 10:
                raise ValueError('Too many attempts; wait five minutes')
            attempts.append(time.monotonic())
            self.pair_attempts[address] = attempts
            if not self.code or time.monotonic() >= self.code_until or not hmac.compare_digest(self.code, str(code)):
                raise ValueError('Show a new connection code on the PC and try again')
            token = secrets.token_urlsafe(32)
            with self.db() as db:
                db.execute('INSERT INTO devices VALUES (?,?)', (hashlib.sha256(token.encode()).hexdigest(), str(name)[:100]))
            self.code = ''  # Single use; existing devices retain their token.
            return token

    def authorized(self, header):
        if not header.startswith('Bearer '):
            return False
        digest = hashlib.sha256(header[7:].encode()).hexdigest()
        with self.db() as db:
            return db.execute('SELECT 1 FROM devices WHERE hash=?', (digest,)).fetchone() is not None

    def jobs(self):
        with self.db() as db:
            return [self.public(row) for row in db.execute('SELECT * FROM jobs ORDER BY start DESC')]

    @staticmethod
    def public(row):
        return {key: row[key] for key in ('id', 'title', 'channel', 'start', 'end', 'state', 'bytes', 'detail', 'weekly', 'series', 'guide_start', 'guide_end')}

    def job(self, job_id):
        with self.db() as db:
            row = db.execute('SELECT * FROM jobs WHERE id=?', (job_id,)).fetchone()
        if row is None:
            raise KeyError('Recording not found')
        return row

    def add(self, body):
        job_id = str(uuid.UUID(str(body['id'])))  # Stable client ID makes a retried request idempotent.
        source = str(body['url'])
        parsed = urlsplit(source)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username:
            raise ValueError('Unsupported channel address')
        if parsed.path.lower().endswith('.m3u8'):
            raise ValueError('Choose an MPEG-TS channel; HLS recording is not supported yet')
        start, end = int(body['start']), int(body['end'])
        now = int(time.time() * 1000)
        if end <= now or end <= start or end - max(start, now) > 24 * 3600 * 1000:
            raise ValueError('Choose a future recording of up to 24 hours')
        guide_start, guide_end = int(body.get('guide_start',start)), int(body.get('guide_end',end))
        if not start <= guide_start < guide_end <= end:
            raise ValueError('Program times must fall inside the recording times')
        weekly = bool(body.get('weekly', False))
        zone = str(body.get('zone', 'UTC'))
        ZoneInfo(zone)  # Reject invalid zones before saving a weekly wall-clock schedule.
        folder = Path(self.setting('folder'))
        if not self.setting('folder') or not folder.is_dir():
            raise ValueError('Choose an available recording folder on the PC first')
        title = str(body['title']).strip()[:180]
        channel = str(body['channel']).strip()[:180]
        filename = re.sub(r'[^\w .-]', '_', title)[:80].rstrip(' .') or 'Recording'
        target = folder / f'{filename}-{job_id}.ts'
        with self.lock, self.db() as db:
            existing = db.execute('SELECT * FROM jobs WHERE id=?', (job_id,)).fetchone()
            if existing:
                return self.public(existing)
            if any(schedules_overlap(start,end,weekly,zone,row) for row in db.execute("SELECT * FROM jobs WHERE state IN ('Scheduled','Recording') OR weekly=1")):
                raise ValueError('Another recording overlaps this time; one recording at a time is supported')
            db.execute('INSERT INTO jobs(id,title,channel,source,start,end,path,state,weekly,zone,series,guide_start,guide_end) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
                       (job_id, title, channel, self.protect(source), start, end, str(target), 'Scheduled', int(weekly), zone, job_id if weekly else '', guide_start,guide_end))
        return self.public(self.job(job_id))

    def update(self, job_id, state, size, detail=''):
        with self.db() as db:
            db.execute('UPDATE jobs SET state=?,bytes=?,detail=? WHERE id=?', (state, size, detail, job_id))

    def cancel(self, job_id):
        with self.lock:
            job = self.job(job_id)
            if job['series']:
                with self.db() as db:
                    db.execute('UPDATE jobs SET weekly=0 WHERE series=?', (job['series'],))
                    db.execute("UPDATE jobs SET state='Cancelled' WHERE series=? AND state IN ('Scheduled','Recording')", (job['series'],))
                    for row in db.execute('SELECT id FROM jobs WHERE series=?', (job['series'],)):
                        if row['id'] in self.active:
                            self.active[row['id']].set()
            if job['state'] in ACTIVE:
                self.update(job_id, 'Cancelled', job['bytes'])
                if job_id in self.active:
                    self.active[job_id].set()
        return self.public(self.job(job_id))

    def delete(self, job_id):
        with self.lock:
            job = self.job(job_id)
            if job['state'] in ACTIVE or job_id in self.active:
                raise ValueError('Stop the recording before deleting it')
            if job['weekly']:
                raise ValueError('Cancel weekly repeats before deleting this recording')
            Path(job['path']).unlink(missing_ok=True)
            with self.db() as db:
                db.execute('DELETE FROM jobs WHERE id=?', (job_id,))

    def tick(self):
        with self.lock, self.db() as db:
            now = int(time.time() * 1000)
            # Roll each recurring series forward exactly once, even after a restart.
            for previous in db.execute('SELECT * FROM jobs WHERE weekly=1 AND advanced=0 AND end<=?', (now,)).fetchall():
                zone = ZoneInfo(previous['zone'])
                start = datetime.fromtimestamp(previous['start']/1000, zone)
                end = datetime.fromtimestamp(previous['end']/1000, zone)
                while end.timestamp()*1000 <= now:
                    start += timedelta(days=7)
                    end += timedelta(days=7)
                start_ms, end_ms = int(start.timestamp()*1000), int(end.timestamp()*1000)
                next_id = str(uuid.uuid5(uuid.UUID(previous['series']), str(start_ms)))
                target = Path(previous['path']).parent / (re.sub(r'[^\w .-]', '_', previous['title'])[:80].rstrip(' .') + '-' + next_id + '.ts')
                db.execute('INSERT OR IGNORE INTO jobs(id,title,channel,source,start,end,path,state,weekly,zone,series,guide_start,guide_end) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    (next_id,previous['title'],previous['channel'],previous['source'],start_ms,end_ms,str(target),'Scheduled',1,previous['zone'],previous['series'],start_ms+((previous['guide_start'] or previous['start'])-previous['start']),end_ms-(previous['end']-(previous['guide_end'] or previous['end']))))
                db.execute('UPDATE jobs SET advanced=1 WHERE id=?', (previous['id'],))
            for job in db.execute("SELECT * FROM jobs WHERE state='Scheduled' AND start<=?", (now,)).fetchall():
                if job['end'] <= now:
                    db.execute('UPDATE jobs SET state=?,detail=? WHERE id=?', ('Partial' if job['bytes'] else 'Missed', 'Recorder was unavailable when recording was due', job['id']))
                elif not self.active:
                    event = threading.Event()
                    self.active[job['id']] = event
                    db.execute("UPDATE jobs SET state='Recording' WHERE id=?", (job['id'],))
                    threading.Thread(target=self.record, args=(job, event), daemon=True).start()

    def record(self, job, cancel):
        size = job['bytes']
        error = ''
        output = None
        try:
            source = self.protect(job['source'], decrypt=True)
            path = Path(job['path'])
            if size and (not path.is_file() or path.stat().st_size < size):
                raise ValueError('The interrupted recording file is unavailable')
            failures = 0
            interruptions = 0
            while not self.stop_event.is_set() and not cancel.is_set() and time.time()*1000 < job['end']:
                began, before = time.monotonic(), size
                try:
                    stream = urlopen(Request(source, headers={'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20', 'Accept': '*/*', 'Cache-Control': 'no-cache'}), timeout=min(10, max(.1, job['end']/1000-time.time())))
                    with stream:
                        prefix = stream.read(564)
                        if len(prefix) < 376 or not any(prefix[i] == 0x47 and prefix[i+188] == 0x47 for i in range(188)):
                            raise StreamUnavailable('Provider returned no video data')
                        if output is None:
                            try:
                                output = path.open('ab' if size else 'xb')
                            except OSError:
                                raise ValueError('Cannot create or resume the recording file') from None
                            size = path.stat().st_size
                        chunk = prefix
                        while chunk and not cancel.is_set() and not self.stop_event.is_set() and time.time()*1000 < job['end']:
                            try:
                                free = shutil.disk_usage(path.parent).free
                            except OSError:
                                raise ValueError('Recording drive is unavailable') from None
                            if free < 64*1024*1024:
                                raise ValueError('Recording drive is almost full')
                            try:
                                output.write(chunk)
                                output.flush()
                            except OSError:
                                raise ValueError('Cannot write to the recording folder') from None
                            size += len(chunk)
                            error = ''
                            with self.lock:
                                if not cancel.is_set():
                                    self.update(job['id'], 'Recording', size)
                            chunk = stream.read1(188*128)
                        if not chunk and time.time()*1000 < job['end']:
                            error = 'Provider connection interrupted'
                except (OSError, TimeoutError, http.client.HTTPException, StreamUnavailable) as exc:
                    # No raw provider URL or credentials in saved errors/logs.
                    error = 'Provider connection interrupted'
                    if isinstance(exc, http.client.IncompleteRead):
                        error = 'Provider ended the stream unexpectedly'
                    elif isinstance(exc, StreamUnavailable):
                        error = str(exc)
                    elif hasattr(exc, 'code'):
                        error = f'Provider returned HTTP {exc.code}'
                if cancel.is_set() or self.stop_event.is_set() or time.time()*1000 >= job['end']:
                    break
                if size - before > 18800 and time.monotonic() - began >= 30:
                    failures = 0
                # A temporary outage must not shorten a scheduled program. Retry
                # the original URL until the scheduled end, user stop or storage failure.
                delay = self.retry_delays[min(failures, len(self.retry_delays)-1)]
                failures += 1
                interruptions += 1
                with self.lock:
                    if not cancel.is_set():
                        self.update(job['id'], 'Recording', size, f'{error}. Reconnecting (attempt {failures}); the schedule remains active.')
                until = min(time.monotonic()+delay, time.monotonic()+max(0,job['end']/1000-time.time()))
                while time.monotonic() < until and not cancel.is_set() and not self.stop_event.is_set():
                    cancel.wait(.1)
        except Exception as exc:
            error = str(exc) if isinstance(exc, ValueError) else 'Recording storage or stream is unavailable'
        finally:
            if output:
                try:
                    output.close()
                except OSError:
                    error = 'Could not finish writing the recording'
            with self.lock:
                if cancel.is_set():
                    state = 'Cancelled'
                elif self.stop_event.is_set():
                    state, error = 'Scheduled', 'Waiting for recorder to restart'
                else:
                    state = ('Partial' if size else 'Failed') if error or not size else 'Completed'
                    if not error and interruptions:
                        error = f'Provider reconnected {interruptions} time(s). Any outage may leave a gap in the recording.'
                self.update(job['id'], state, size, error)
                self.active.pop(job['id'], None)

    def start(self, host='0.0.0.0'):
        owner = self
        class Handler(http.server.BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'
            def log_message(self, *args):
                pass
            def send_json(self, status, body):
                data = json.dumps(body).encode()
                self.send_response(status)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(data)
            def handle_api(self):
                path = urlsplit(self.path).path
                try:
                    if self.command == 'GET' and path == '/v1/info':
                        return self.send_json(200, {'name': socket.gethostname(), 'version': '0.2.0', 'service': 'greenstreem-recorder'})
                    body = {}
                    if self.command == 'POST':
                        length = int(self.headers.get('Content-Length', '0'))
                        if length < 0 or length > 32768:
                            raise ValueError('Request is too large')
                        self.connection.settimeout(10)
                        body = json.loads(self.rfile.read(length) or '{}')
                    if self.command == 'POST' and path == '/v1/pair':
                        return self.send_json(200, {'token': owner.pair(body.get('code'), body.get('name','Device'), self.client_address[0])})
                    if not owner.authorized(self.headers.get('Authorization','')):
                        return self.send_json(401, {'error': 'Connect this device to the recorder first'})
                    if path == '/v1/jobs':
                        if self.command == 'GET':
                            return self.send_json(200, {'jobs': owner.jobs(), 'folder': owner.setting('folder'), 'capacity': 1})
                        if self.command == 'POST':
                            return self.send_json(201, owner.add(body))
                    match = re.fullmatch(r'/v1/jobs/([0-9a-f-]{36})(/cancel|/content)?', path)
                    if match:
                        job_id, action = match.groups()
                        if self.command == 'POST' and action == '/cancel':
                            return self.send_json(200, owner.cancel(job_id))
                        if self.command == 'DELETE' and action is None:
                            owner.delete(job_id)
                            return self.send_json(200, {'deleted': True})
                        if self.command == 'GET' and action == '/content':
                            job = owner.job(job_id)
                            if job['state'] not in ('Completed', 'Partial', 'Cancelled'):
                                raise ValueError('Recording is not ready for replay')
                            return self.content(Path(job['path']))
                    self.send_json(404, {'error':'Not found'})
                except KeyError:
                    self.send_json(404, {'error': 'Recording or required field not found'})
                except (ValueError, TypeError):
                    self.send_json(400, {'error': 'Check recording times, available folder, overlapping schedules, or connection code'})
                except (OSError, sqlite3.Error):
                    self.send_json(503, {'error': 'Recorder storage is unavailable'})
            def content(self, path):
                with path.open('rb') as stream:
                    size = os.fstat(stream.fileno()).st_size
                    start, end = 0, size-1
                    requested = self.headers.get('Range')
                    if requested:
                        match = re.fullmatch(r'bytes=(\d*)-(\d*)', requested)
                        if not match or not any(match.groups()):
                            return self.range_error(size)
                        left, right = match.groups()
                        if left:
                            start, end = int(left), min(int(right), size-1) if right else size-1
                        else:
                            start = max(0, size-int(right))
                        if start > end or start >= size:
                            return self.range_error(size)
                    self.send_response(206 if requested else 200)
                    self.send_header('Content-Type','video/mp2t')
                    self.send_header('Accept-Ranges','bytes')
                    self.send_header('Content-Length',str(max(0,end-start+1)))
                    if requested:
                        self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
                    self.end_headers()
                    stream.seek(start)
                    remaining = end-start+1
                    while remaining > 0:
                        chunk = stream.read(min(65536,remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
            def range_error(self, size):
                self.send_response(416)
                self.send_header('Content-Range',f'bytes */{size}')
                self.send_header('Content-Length','0')
                self.end_headers()
            do_GET = handle_api
            do_POST = handle_api
            do_DELETE = handle_api
        self.http = http.server.ThreadingHTTPServer((host,self.port),Handler)
        self.http.daemon_threads = True
        self.port = self.http.server_port
        threading.Thread(target=self.http.serve_forever, daemon=True).start()
        threading.Thread(target=self.loop, daemon=True).start()
        threading.Thread(target=self.discovery, daemon=True).start()

    def loop(self):
        # Windows keeps awake while the recorder is running, including before future jobs.
        if os.name == 'nt':
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
        try:
            while not self.stop_event.wait(.5):
                self.tick()
        finally:
            if os.name == 'nt':
                ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)

    def discovery(self):
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as udp:
            try:
                udp.bind(('',DISCOVERY_PORT))
                udp.settimeout(1)
                while not self.stop_event.is_set():
                    try:
                        data,address = udp.recvfrom(512)
                        if data == b'GREENSTREEM_RECORDER_DISCOVER_V1':
                            udp.sendto(json.dumps({'name':socket.gethostname(),'port':self.port,'service':'greenstreem-recorder'}).encode(),address)
                    except socket.timeout:
                        pass
            except OSError:
                pass  # Manual address remains available if another instance owns discovery.

    def close(self):
        self.stop_event.set()
        if self.http:
            self.http.shutdown()
            self.http.server_close()
        until = time.monotonic()+12
        while self.active and time.monotonic() < until:
            time.sleep(.1)
